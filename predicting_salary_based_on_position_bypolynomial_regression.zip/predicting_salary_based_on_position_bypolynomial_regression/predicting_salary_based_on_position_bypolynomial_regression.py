# -*- coding: utf-8 -*-
"""
# Polynomial Regression

A candidate negotiates certain amount(160k) of salary in an interview based on his salary in previous company.Company wants to check wheather the candidate is telling truth about his salary in previous company or bluffing.

1.After going through his resume it is evident that this candidate was Region mananger in his previous comapany so his salary might be between level 6 and level 7.
2.So we are Building Linear and  polynomial regression model to predict and compare Salary of a person based on the  position in a company at level 6.5. 

3.Our dataset is the salary of an employee at different position in his previous company.

## Importing the libraries
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

"""## Importing the dataset"""

dataset = pd.read_csv('/Position_Salaries.csv')
x = dataset.iloc[:,1:-1].values
y = dataset.iloc[:,-1].values

"""## Training the Linear Regression model on the whole dataset"""

from sklearn.linear_model import LinearRegression
regressor1 = LinearRegression()
regressor1.fit(x,y)#fitting linear regression model without splitting the data so that we can work on whole data

"""In polynomial regression the power of x refer to features in this example we have two features so value of n is 2 in polynomial regression formula

## Training the Polynomial Regression model on the whole dataset
"""

from sklearn.preprocessing import PolynomialFeatures # sklearn preprocessing contain preprocessing on exponential powered featured
poly_regres = PolynomialFeatures(degree = 4)
x_poly = poly_regres.fit_transform(x)# fit_transform proceed to a transformation of a matrix of single feature to a new  matrix of x1 as the first feature and x2 as the second feature
regressor2 = LinearRegression()
regressor2.fit(x_poly,y)

"""## Visualising the Linear Regression results"""

plt.scatter(x,y,color= 'purple')
plt.plot(x,regressor1.predict(x),color = 'red')
plt.title("Truth or bluff(Linear Regression)")
plt.xlabel("Position level")
plt.ylabel("Salary")
plt.show()

"""We can see that in the above graph the actual salary is far away from the predcted salary.

## Visualising the Polynomial Regression results
"""

plt.scatter(x,y,color= 'purple')
plt.plot(x,regressor2.predict(x_poly),color = 'red')
plt.title("Truth or bluff(Polynomial Regression)")
plt.xlabel("Position level")
plt.ylabel("Salary")
plt.show()

"""The graph is overfitted but we can get idea of the salary of a person aprroximately accurate

## Visualising the Polynomial Regression results (for higher resolution and smoother curve)
"""

x_grid = np.arange(min(x),max(x),0.20)
x_grid = x_grid.reshape(len(x_grid),1)
plt.scatter(x,y,color= 'purple')
plt.plot(x_grid,regressor2.predict(poly_regres.fit_transform(x_grid)),color = 'red')
plt.title("Truth or bluff(Polynomial Regression)")
plt.xlabel("Position level")
plt.ylabel("Salary")
plt.show()

"""## Predicting a new result with Linear Regression"""

regressor1.predict([[6.5]])#  row first dimension col second dimension in double brackets

"""Here we can see the predicted salary is very low from what the candidate expected so he might be bluffing.

## Predicting a new result with Polynomial Regression
"""

regressor2.predict(poly_regres.fit_transform([[6.5]]))

"""Here we can see the predicted salary is same as  what the candidate expected so he is not be bluffing"""